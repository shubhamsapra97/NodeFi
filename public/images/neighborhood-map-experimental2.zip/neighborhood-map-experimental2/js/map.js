var map;
var pubs = [];
var infoContent;



var locations = [
  {name: 'The Pub at Ghirardelli Square', latlng: {lat: 37.8063722222, lng: -122.4228888889}},
  {name: 'The Irish Bank', latlng: {lat: 37.7902750000, lng: -122.4048472222}}, 
  {name: 'Rogue San Francisco Public House', latlng: {lat: 37.8001440000, lng: -122.4104550000}}, 
  {name: 'Chieftain Irish Restaurant & Pub', latlng: {lat: 37.7814900000, lng: -122.4051510000}}, 
  {name: 'Kennedy\'s Irish Pub and Curry House', latlng: {lat: 37.8042510000, lng: -122.4156040000}},
  {name: 'Murphy\'s Pub', latlng: {lat: 37.7901916667, lng: -122.4038472222}}
];


//tells the view model what to do when a change occurs
function Location(value) {
  this.name = ko.observable(value.name);
  this.latlng = ko.observable(value.latlng);
  this.marker = ko.observable(value.marker);
};
//ViewModel
function ViewModel() {
  var self = this;
  var places = [];
  //copies the values of locations and stores them in sortedLocations(); observableArray
  self.sortedLocations = ko.observableArray(locations);

  this.locationList = ko.observableArray([]);
  locations.forEach(function(locationItem) {
    self.locationList.push(new Location(locationItem));
  });

  self.currentLocation = ko.observable(this.locationList()[0]);
  this.setLocation = function(clickedLocation) {
    self.currentLocation(clickedLocation);
    console.log("I was clicked!");
    google.maps.event.trigger(clickedLocation.marker, 'click');
    bounceMarker(clickedLocation.marker);
  }

  //stores user input
  self.query = ko.observable('');
  
  
  //Filter through observableArray and filter results using knockouts utils.arrayFilter();
  self.search = ko.computed(function() {
    return ko.utils.arrayFilter(self.sortedLocations(), function(listResult) {
      filterMarker = listResult.name.toLowerCase().indexOf(self.query().toLowerCase()) >= 0;
      if(typeof(listResult.marker) !==  "undefined") {
        listResult.marker.setVisible(filterMarker);
      }
      return filterMarker;
    });
  });


  function bounceMarker(marker) {
    if (marker.getAnimation() !== null) {
      marker.setAnimation(null);
    } else {
      marker.setAnimation(google.maps.Animation.BOUNCE);
      setTimeout(function() {
          marker.setAnimation(null);
      }, 2100);  // 3 bounces then stops
    }
  }

};
//create instance of a map from the Google Maps API
//Grab the reference to the "map" id to display the map
//Set the map options object properties
function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: {
      lat: 37.7884162, 
      lng: -122.4127457
    },
    zoom: 14
  });

  var infowindow = new google.maps.InfoWindow();

  var marker, i;

  //create the map markers and the infowindows
  function createMarker(latlng, html) {
    //html = '<h4>' + locations[i].name + '</h4>' + "\n" + '<div class="zomato">' + pubs + '</div>';
    //html = '<h4>' + locations[i].name + '</h4>';
    //console.log(html);
    latlng = new google.maps.LatLng(locations[i].latlng.lat, locations[i].latlng.lng);
    marker = new google.maps.Marker({
      position: latlng, 
      map: map, 
      animation: google.maps.Animation.DROP,
      id: i
    });

    google.maps.event.addListener(marker, 'click', (function(marker, i) {

      $.ajax({
        method: "GET",
        crossDomain: true,
        url: "https://developers.zomato.com/api/v2.1/search?count=6&lat=37.79161&lon=-122.42143&establishment_type=6",
        dataType: "json",
        async: true,
        headers: {
          "user-key": "0a661374a6b58eb2fa84142d27fe81ca"
        }, 
        success: function(data) {

          for (i = 0; i < data.restaurants.length; i++) {
            (function(i) {
              var cuisines = data.restaurants[i].restaurant.cuisines;
              var name = data.restaurants[i].restaurant.name;
              console.log(name);
              infoContent = '<h4>' + name + '</h4>' + "\n" + '<div class="zomato">' + cuisines + '</div>'; 
            })(i);
          }
        }
      });

      return function() {
        infowindow.setContent(infoContent);
        infowindow.open(map, marker);
      }
    })(marker, i));

  return marker;
  }

  //this makes it possible for KO to render the markers and infowindow's click binding
  for(i = 0; i < locations.length; i++) {
    locations[i].marker = createMarker(new google.maps.LatLng(locations[i].lat, locations[i].lng));
  }

};

var vm = new ViewModel();
  
ko.applyBindings(vm);